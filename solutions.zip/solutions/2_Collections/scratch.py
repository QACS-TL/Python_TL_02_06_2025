i = 3
i -= 2
print(i)

s = "Hello"

s -= "lo"

print(s)

