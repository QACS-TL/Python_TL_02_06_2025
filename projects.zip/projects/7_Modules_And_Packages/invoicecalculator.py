fastfood = {'Coke': [0.99, 1.29, 1.49], 'Fries': [1.99, 2.49, 2.99], 'Burger': [4.99, 5.99, 6.99], 'Nuggets': [3.95, 4.85, 5.75]}

def get_item_price(requesteditem:tuple[str,str])->float:
    food_type, size = requesteditem
    price_pos = 0
    if size == "small":
        price_pos = 0
    elif size == "medium":
        price_pos = 1
    else:
        price_pos = 2
    price = fastfood[food_type][price_pos]
    return price

def get_total_price(requesteditems:list[tuple[str,str]])->float:
    total_price = 0
    for item in requesteditems:
        total_price += get_item_price(item)
    return total_price