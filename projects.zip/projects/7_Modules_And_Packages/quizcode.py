# Q1

# A.
# import arithmetic
# result = arithmetic.add(2, 3)
# print(result)

# B.
# from arithmetic import add
# result = add(2, 3)
# print(result)

# C.
# from add import arithmetic
# result = arithmetic.add(2, 3)
# print(result)

# D.
# import add from arithmetic
# result = add(2, 3)


# Q4
# See invoicecalculator.py and invoicecalculatortests.py