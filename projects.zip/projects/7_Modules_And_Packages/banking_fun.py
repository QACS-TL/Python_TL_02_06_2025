import sys
sys.path.append(r".\Finance")
import Finance

bal = 100
bal = Finance.banking.withdraw(bal)
bal = Finance.banking.deposit(bal)
print(bal)






