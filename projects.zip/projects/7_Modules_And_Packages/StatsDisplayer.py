import pstats

# Load the profiling data
stats = pstats.Stats("afterstats.prof")

# Sort by a desired metric (e.g., time)
stats.sort_stats("time")

# Print the results
stats.print_stats(10)  # Prints the top 10 lines

stats.print_stats()
