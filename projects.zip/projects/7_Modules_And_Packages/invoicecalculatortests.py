import unittest
from invoicecalculator import get_item_price, get_total_price


class TestItem(unittest.TestCase):

    def test_individual_orders_item(self):
        items = [("Coke", "small"), ("Burger", "large")]
        self.assertEqual(get_item_price(items[0]), 0.99)
        self.assertEqual(get_item_price(items[1]), 6.99)

    def test_grand_total(self):
        items = [("Coke", "small"), ("Burger", "large")]
        self.assertEqual(get_total_price(items), 7.98)
        