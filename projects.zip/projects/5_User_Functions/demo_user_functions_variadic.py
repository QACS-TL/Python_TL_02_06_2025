#! /bin/python
# Name:        demo_user_functions_variadic.py
# Author:      QA2.0, Donald Cameron
# Revision:    v1.0
# Description: This program will demonstrate how to
# define, name, call and pass parameters in and return None.
"""
    Displays greeting messages to ALL friends and foes.
"""
import sys


# Example of a Variadic function.
def say_hello(greeting="Hi",  *recipients):
    """
    Accept a greeting string and variable number of recipients and
    display message to ALL recipients and returns None.
    """
    # Use an iterator for loop to iterate through objects in tuple.
    for person in recipients:
        message = str(greeting) + " " + str(person)
        print(message)

    # return None
    return None


def force_callee_to_use_name_of_parameters( name="Anon", *, age=21, phone="01234567890"):
    print(f"Welcome {name}, you are {age} years old and I know your phone number, it's {phone}")


def my_variadic_function_that_makes_a_dictionary_out_of_the_parameters(**kwargs):
    for key in kwargs.keys():
        print(f"key: {key}, value: {kwargs[key]}")


def main():
    """ Main function - say hello to our friends """

    # Pass in a variable number of parameters to the function.
    say_hello()
    say_hello('None shall pass')
    say_hello(greeting='None shall pass' )
    say_hello('None shall pass', "Lancelot" )
    say_hello('None shall pass', 'green knight', 'arthur', 'patsy')


    parms = {'title':"Postman Pat in the Heist", 'duration':6, 'release_year':2023, 'rating':11, 'quality':"Bad"}
    # my_variadic_function_that_makes_a_dictionary_out_of_the_parameters(parms)
    my_variadic_function_that_makes_a_dictionary_out_of_the_parameters(
        title="Postman Pat in the Heist", duration=6, release_year=2023, rating=11, quality="Bad")

    force_callee_to_use_name_of_parameters("Brian", 33, "0234567890")
    force_callee_to_use_name_of_parameters( age=33, phone="0234567890", name="Brian")

    return None


if __name__ == "__main__":
    main()
    sys.exit(0)

