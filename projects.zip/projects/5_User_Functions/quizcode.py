# Q1
# def calculator(num1, num2):
#     first_value = num1 + 7
#     second_value = num2 - 6
#     return first_value
#
# calculator(13, 10)


# Q2

# def calculator(num1, num2):
#     fval = num1 + 7
#     sval = num2 - 6
#     tval = trebler(sval)
#     return tval
#
# def trebler(aval):
#     return (aval * 3)
#
# calculator(13, 10)
# print(sval)


# Q3
# num = 3
#
# def num_fun(a=5):
#     num = a
#     return num
#
# num_fun(7)
#
# print(num)




# Q4
# def reset_val():
#     global val
#     if True:
#         val = 40
#
# reset_val()
#
# if False:
#     val = 66
#
# print(val)

# Q5
def my_function(pos=0, *pets):
  print("The chosen pet is " + pets[pos])

my_function(2,"Gnasher", "Flipper", "Lassie")
