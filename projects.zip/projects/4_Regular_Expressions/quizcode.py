# Q1
import re
emails = open('C:\labs\emailstore.txt')
for line in emails:
    line = line.rstrip()
    if re.search('^From:', line):
        print(line)

# Q2
import re

emails = 'From: kamran.a.dehinad@qa.com, sadia.liaqat@qa.com, Leilani.nguyen@qa.com'

emails = emails.rstrip()
print(re.findall('From:.+?@', emails))


# Q3

codeA = "Y-LOCN-Probability: Accurate"
codeB = "Y-LOCN-Confidence: 0.8475"
codeC = "Y-Splat-Area 1"
codeD = "Y Splat-Area: 0.53"

if re.search('^Y-.*: [0-9.]+', codeA):
    print(codeA)

if re.search('^Y-.*: [0-9.]+', codeB):
    print(codeB)

if re.search('^Y-.*: [0-9.]+', codeC):
    print(codeC)

if re.search('^Y-.*: [0-9.]+', codeD):
    print(codeD)