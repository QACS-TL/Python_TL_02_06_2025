# Create a variable to store your name (string)
name = "Arthur"

# Create a variable to store your age (integer)
age = 42

# Create a variable to store your height in meters (float)
height = 1.80

# Create a boolean variable to indicate if you are a student
is_student = True

# Print all the variables
print("Name:", name)
print("Age:", age)
print("Height:", height)
print("Is a student:", is_student)

print("Type of name:", type(name))
print("Type of age:", type(age))
print("Type of height:", type(height))
print("Type of is_student:", type(is_student))