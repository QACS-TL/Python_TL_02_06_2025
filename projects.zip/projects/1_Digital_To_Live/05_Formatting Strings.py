# Variables
name = "Arthur"
age = 42
height = 1.80
country = "Britain"

# Using yucky concatenation
print("I am " + name + ", I am " + str(age) + " years old, " + "{:.2f}".format(height) + "m tall, and I live in " + country + ".")

# Use f-string to format and print the information
print(f"I am {name}, I am {age} years old, {height:.2f}m tall, and I live in {country}.")