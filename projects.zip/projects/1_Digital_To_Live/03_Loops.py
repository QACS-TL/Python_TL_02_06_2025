for i in range(1, 11):
    print(i)


total_sum = 0
number = 1

while number <= 100:
    total_sum += number
    number += 1

print("The sum of numbers from 1 to 100 is:", total_sum)

