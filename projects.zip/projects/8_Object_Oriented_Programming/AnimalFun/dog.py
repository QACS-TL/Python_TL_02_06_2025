from animal import Animal

class Dog(Animal):
    def __init__(self, name="Fido", colour="Black", limbcount=4, taillength=30):
        super().__init__(name, colour, limbcount)
        self.taillength = taillength

    def eat(self, food):
        val = super().eat(food)  # calls super classes eat method
        return f"{val}. Actually I'm a dog chomping on a {food}"

    def bark(self, number_of_times):
        return "woof " * number_of_times
