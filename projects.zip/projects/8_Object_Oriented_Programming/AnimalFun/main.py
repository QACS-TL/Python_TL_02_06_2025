from animal import Animal
from animal import Vegetable
from dog import Dog


dg1 = Dog("Bonzo", "Red", 5, 45)

print(dg1.eat("Bone"))


print(dg1.bark(5))



ani1 = Animal("Rover", "Brown", 3)
# ani1._limbcount = 4
ani1.set_limbcount(1)

print(ani1.get_limbcount())

ani1.limbcount = -100
print(ani1.limbcount)

ani1.limbcont = 45


# ani1.name = "Rover"
# ani1.colour = "Blue"

ani2 = Animal("Fido", "Pink")
# ani2.limbcount = 5
# ani2.name = "Fido"
# ani2.colour = "Pink"

print(ani1.eat("muesli"))
print(ani2.eat("cheese"))


veg1 = Vegetable()
veg1.create_vegetable("mr carrot")
veg1.colour = "Green"
