"""
This exercise stub and the test suite contain several enumerated constants.

For this challenge, enumerated constants are written as a NAME assigned to an
arbitrary, but unique value. An integer is traditionally used because it’s memory
efficient.
It is a common practice to export both constants and functions that work with
those constants (ex. the constants in the os, subprocess and re modules).

You can learn more here: https://en.wikipedia.org/wiki/Enumerated_type
"""

# Possible sublist categories.
# Change the values as you see fit.
SUBLIST = 1
SUPERLIST = 2
EQUAL = 3
UNEQUAL = 4

#Naive Approach

# def listcheck(A, B):
#     for i in range(len(B) - len(A) + 1):
#         for j in range(len(A)):
#             if B[i + j] != A[j]:
#                 break
#         else:
#             return True
#
#     return False

# Better using list comprehension
# def listcheck(A, B):
#     n = len(A)
#     return any(A == B[i:i + n] for i in range(len(B)-n + 1))

# Better using join and map module
# Here we use join to join both lists to strings
# and then use in operator to check if list A is contained in B or not.
# def listcheck(A, B):
#     return ', '.join(map(str, A)) in ', '.join(map(str, B))


# Better using Regular Expressions
import re
def listcheck(A, B):
    # convert list A to string
    A_str = '  '.join(map(str, A))
    # convert list B to string
    B_str = '  '.join(map(str, B))
    # find all instances of A within B
    instances = re.findall(A_str, B_str)

    # return True if any instances were found, False otherwise
    return len(instances) > 0

def sublist(list_one, list_two):
    val = 0
    if list_one == list_two:
        val = EQUAL
    else:
        if listcheck(list_one, list_two):
            val = SUBLIST
        else:
            if listcheck(list_two, list_one):
                val = SUPERLIST
            else:
                val = UNEQUAL


    return val
