def accumulate(collection, operation):
    new_collection = []
    for n in collection:
        new_collection.append(operation(n))
    return new_collection