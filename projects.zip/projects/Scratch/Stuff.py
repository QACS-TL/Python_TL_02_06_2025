mystring = "hello"
mystring = mystring + " World"
print(mystring)


mytuple = ("hello", 123, 34.9, None)
# mytuple[2] = 50

mylist = [1, 3, 5, 7, 9]
mylist[3] = 99
print(mylist)
# mylist[3] = ["A", "B", "C"]
print(mylist)
mylist.append(100)
n = mylist.pop(3)
print(n)
print(mylist)


mydict = {1: "banana", 5: [1,23,54,67], 3: "chocolate", "three": "cake"}
mydict["three"] = "carrot"

print(mydict["three"])

myset = { 2, 4, 6, 8, 8}
myset.add(9)
myset.add(8)
print(myset)
