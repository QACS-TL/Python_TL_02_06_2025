# Reverse String

Reverse a string

For example:
input: "cool"
output: "looc"

## Running the tests

To run the tests, run `pytest reverse_string_test.py`

Alternatively, you can tell Python to run the pytest module:
`python -m pytest reverse_string_test.py`