def reverse(text):
    new_string = ''
    # use slicing and step back by -1
    #new_string = text [::-1]

    # slower but more readable
    #new_string = ''.join(reversed(text))

    # super clunky
    index = len(text)
    while index:
        index -= 1                    # index = index - 1
        new_string += text[index] # new_string = new_string + character
    return new_string
