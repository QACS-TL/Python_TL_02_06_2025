

def frange(val, stop=None, step=0.25):
    if stop is None:
        stop = val
        start = 0

    if step == 0 or val > stop:
        return []

    curr = float(val)
    while curr < stop:
        yield round(curr, 2)
        curr += step


print(list(frange(1.1, 3)))
print(list(frange(1.1, 3, 0.33)))
print(list(frange(1, 3, 1)))
print(list(frange(3, 1)))
print(list(frange(1, 3, 0)))
print(list(frange(-1.0, -0.5, 0.1)))

print(list(frange(val=3.5)))

for num in frange(3.142, 12):
    print(num)