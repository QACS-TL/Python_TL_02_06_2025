# using a comprehension
def find_anagrams(word, candidates):
    # Sort the characters of the word to create a standard form
    sorted_word = sorted(word.lower())

    # Create a sublist of candidates that are anagrams of the word
    anagrams = [
        candidate for candidate in candidates
        if sorted(candidate.lower()) == sorted_word and candidate.lower() != word.lower()
    ]

    return anagrams

# alternative using traditional loops and conditionals
# def find_anagrams(word, candidates):
#     # Convert the word to lowercase and sort its characters
#     sorted_word = sorted(word.lower())
#
#     # Initialize an empty list to store anagrams
#     anagrams = []
#
#     # Iterate through each candidate
#     for candidate in candidates:
#         # Convert candidate to lowercase
#         lower_candidate = candidate.lower()
#
#         # Skip the candidate if it is the same as the original word
#         if lower_candidate == word.lower():
#             continue  # Skip to the next candidate
#
#         # Check if sorted candidate matches sorted_word
#         if sorted(lower_candidate) == sorted_word:
#             anagrams.append(candidate)  # Add original candidate to the anagrams list
#
#     return anagrams