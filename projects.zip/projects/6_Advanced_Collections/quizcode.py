# Q1
# ages = [('Ted',55), ('Marie',12), ('Abena',37), ('Zuri', 18), ('Kofi', 17), ('Ade', 24), ('Anton',5)]
#
# def myFunc(x):
#   if x[1] < 18:
#     return False
#   else:
#     return True
#
# adults = filter(myFunc, ages)
#
# for x in adults:
#   print(x)


# Q2
# people = {'Ted': 55, 'Marie': 12, 'Abena': 37, 'Zuri': 18, 'Kofi': 17, 'Ade': 24, 'Anton': 5}
#
# adults = [person for person in people if people[person] >= 18]
# for x in adults:
#     print(x)
