
def frange(start, stop=None, step=0.25):
    if step == 0:
        return []

    if stop is None:
        stop = start
        start = 0
    #
    # curr = float(start)
    #
    # while curr < stop:
    #     yield round(curr, 2)
    #     curr += step

    return (i / 1000 for i in range(int(start * 1000), int(stop * 1000), int(step * 1000)))



def main():
    """ The Main Program """
    print(list(frange(1.1, 3)))
    print(list(frange(1, 3, 0.33)))
    print(list(frange(.001, 0.0063, 0.00334343)))
    print(list(frange(1, 3, 1)))  # Should return [1.0, 2.0], not [1, 2]
    print(list(frange(3, 1)))  # Should return an empty list
    print(list(frange(1, 3, 0)))  # Should return an empty list
    print(list(frange(-1, -0.5, 0.1)))
    print(frange(1, 2))  # Should print <generator object frange at 0x..
    #
    for num in frange(3.142, 12):
        print(f"{num:05.2f}")
    return None


if __name__ == "__main__":
    main()








    # return (i/1000 for i in range(start * 1000, stop * 1000, int(step * 1000)))
