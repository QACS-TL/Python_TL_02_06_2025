def frange(start, stop, step=0.25):
    if step == 0:
        print("step cannot be 0")
        return
    # nums = []
    while start < stop:
        yield start
        start += step
    #return nums

for i in frange(0.6,4, 0.2):
    print(i)

