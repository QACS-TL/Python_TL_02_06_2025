from animal import Animal
from elephant import Elephant
# name = input("Please enter an animal name: ")

ani1 = Animal("Biffo", 3, "Pink", 103, 96)
# ani1.name = "Biffo"
# ani1.cage = 101
ani1.limb_count = -1
# ani1.set_limb_count(-1)
ani1.limbcount = 10
print(ani1.limbcount)

ani2 = Animal("Doreen",  color="Grey", cage=107, health=85)
# ani2.name = input("Please enter an animal name: ")
# ani2.colour = "Grey"
# ani2.cage = 102
# ani2.health = 90

ani3 = Animal()

ele = Elephant("Dumbo", 4,  "Grey", 199, 50, 2.0)
# ele.name = "Dumbo"
# ele.colour = "Grey"
print(ele.squirt_water())

print(ani1.move(10, "down"))
print(ani2.move(30, "North"))
print(ani3.move(25, "West"))
print(ele.move(100, "over there"))

print(ani1.limb_count)

zoo = list()
zoo.append(ani1)
zoo.append(ani2)
zoo.append(ani3)
zoo.append(ele)

# FEEDING TIME
for a in zoo:
    print(a.eat("Cheese"))
    if type(a) is Elephant:
        # print(a)
        print((Elephant(a)).squirt_water())