from animal import Animal

class Elephant(Animal):

    def __init__(self, name="Dumbo", limb_count=4, colour="Grey", cage=200, health=100, trunk_length=1.5):
        super().__init__(name, limb_count, colour, cage, health)
        self.trunk_length = trunk_length

    def squirt_water(self):
        return f"I'm an elephant called {self.name} squirting water!"

    def eat(self, food):
        # calculate the calorific value of the food
        self.health += 5
        # super().eat(food)
        return f"I'm a {self.colour} ELEPHANT called {self.name} using my trunk to eat {food}." + super().eat(food)