class Animal:
    # name = "Anonymous"
    # limb_count = 4
    # colour = "Brown"
    # cage = 100
    # health = 100

    def __init__(self, name="Anonymous", limb_count=4, color="Brown", cage=100, health=100):
        self.name = name
        self._limb_count = limb_count
        self.colour = color
        self.cage = cage
        self.health = health

    def get_limb_count(self):
        return self._limb_count

    def set_limb_count(self, value):
        if value < 0:
            value = 0
        self._limb_count = value

    limb_count = property(get_limb_count, set_limb_count)

    def eat(self, food):
        # calculate the calorific value of the food
        self.health += 5
        return f"I'm a {self.colour} animal called {self.name} eating {food}."

    def move(self, distance=5, direction="up"):
        return f"I'm a {self.colour} animal called {self.name} using my {self._limb_count} limbs to move {direction} for {distance} metres."

    def __str__(self):
        return f"I'm a {self.colour} animal called {self.name} I have {self._limb_count} limbs"